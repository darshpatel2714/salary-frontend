import React, { useState } from 'react';
import axios from 'axios';

const SalaryForm = () => {
    const [salaryData, setSalaryData] = useState({
        salaryRate: '',
        inTime: '',
        outTime: '',
        regularHours: '',
        overtimeHours: '',
        // Other fields...
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setSalaryData((prevData) => ({ ...prevData, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Calculations
        // const regularHoursAmount = salaryData.salaryRate;
        const regularHoursAmount = parseFloat(salaryData.salaryRate);
        const overtimeAmount = (regularHoursAmount / salaryData.regularHours) * salaryData.overtimeHours;
        const totalAmount = parseFloat(regularHoursAmount) + parseFloat(overtimeAmount);
        const pf = regularHoursAmount * 0.12;
        const totalSalary = totalAmount - pf;
       

        try {
            const response = await axios.post('http://localhost:5000/api/salary', {
                ...salaryData,
                regularHoursAmount,
                overtimeHoursAmount: overtimeAmount,
                totalAmount,
                pf,
                totalSalary,
                
            });
            console.log('Salary data saved:', response.data);
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="number" name="salaryRate" placeholder="Salary Rate" onChange={handleChange} required />
            <input type="text" name="inTime" placeholder="In Time" onChange={handleChange} required />
            <input type="text" name="outTime" placeholder="Out Time" onChange={handleChange} required />
            <input type="number" name="regularHours" placeholder="Regular Hours" onChange={handleChange} required />
            <input type="number" name="overtimeHours" placeholder="Overtime Hours" onChange={handleChange} />
            <button type="submit">Calculate Salary</button>
        </form>
    );
};

export default SalaryForm;